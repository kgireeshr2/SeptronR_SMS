/* ============================================================
   RiseArka — Shared JavaScript
   ============================================================ */

/* ── Scroll progress bar ─────────────────────────────────────── */
(function () {
  const bar = document.createElement('div');
  bar.id = 'scrollProgress';
  document.body.prepend(bar);
  window.addEventListener('scroll', () => {
    const pct = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
    bar.style.width = Math.min(pct, 100) + '%';
  }, { passive: true });
})();

/* ── Navbar scroll ──────────────────────────────────────────── */
(function () {
  const navbar = document.getElementById('navbar');
  if (!navbar) return;
  const onScroll = () => navbar.classList.toggle('scrolled', window.scrollY > 30);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();

/* ── Mobile menu ─────────────────────────────────────────────── */
(function () {
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobileMenu');
  const overlay = document.getElementById('mobileOverlay');
  if (!hamburger) return;

  const open = () => {
    hamburger.classList.add('open');
    mobileMenu.classList.add('open');
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  };
  const close = () => {
    hamburger.classList.remove('open');
    mobileMenu.classList.remove('open');
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  };

  hamburger.addEventListener('click', () => mobileMenu.classList.contains('open') ? close() : open());
  overlay.addEventListener('click', close);
  document.querySelectorAll('.mobile-link').forEach(l => l.addEventListener('click', close));
  document.addEventListener('keydown', e => e.key === 'Escape' && close());
})();

/* ── Reveal on scroll ────────────────────────────────────────── */
(function () {
  const els = document.querySelectorAll('[data-reveal]');
  if (!els.length) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('revealed'); io.unobserve(e.target); } });
  }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
  els.forEach(el => io.observe(el));
})();

/* ── Animated counters ───────────────────────────────────────── */
(function () {
  const counters = document.querySelectorAll('[data-count]');
  if (!counters.length) return;
  const ease = (t) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;

  const runCounter = (el) => {
    if (el._counted) return;
    el._counted = true;
    const end = parseFloat(el.dataset.count);
    const duration = 1800;
    const start = performance.now();
    const isFloat = String(end).includes('.');
    const decimals = isFloat ? (String(end).split('.')[1] || '').length : 0;

    const step = (now) => {
      const p = Math.min((now - start) / duration, 1);
      const val = ease(p) * end;
      el.textContent = isFloat ? val.toFixed(decimals) : Math.floor(val).toLocaleString();
      if (p < 1) requestAnimationFrame(step);
      else el.textContent = isFloat ? end.toFixed(decimals) : end.toLocaleString();
    };
    requestAnimationFrame(step);
  };

  const io = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) runCounter(e.target); });
  }, { threshold: 0.3 });
  counters.forEach(el => io.observe(el));
})();

/* ── Tabs ────────────────────────────────────────────────────── */
(function () {
  document.querySelectorAll('[data-tab-container]').forEach(container => {
    const buttons = container.querySelectorAll('[data-tab]');
    const panels = container.querySelectorAll('[data-tab-panel]');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.tab;
        buttons.forEach(b => b.classList.toggle('active', b.dataset.tab === target));
        panels.forEach(p => p.classList.toggle('active', p.dataset.tabPanel === target));
      });
    });
  });
})();

/* ── Carousel ────────────────────────────────────────────────── */
(function () {
  document.querySelectorAll('[data-carousel]').forEach(carousel => {
    const track = carousel.querySelector('[data-carousel-track]');
    const slides = carousel.querySelectorAll('[data-carousel-slide]');
    const dots = carousel.querySelectorAll('[data-carousel-dot]');
    const prev = carousel.querySelector('[data-carousel-prev]');
    const next = carousel.querySelector('[data-carousel-next]');
    if (!track || !slides.length) return;

    let current = 0;
    const total = slides.length;

    const goTo = (idx) => {
      current = (idx + total) % total;
      track.style.transform = `translateX(-${current * 100}%)`;
      dots.forEach((d, i) => d.classList.toggle('active', i === current));
    };

    prev?.addEventListener('click', () => goTo(current - 1));
    next?.addEventListener('click', () => goTo(current + 1));
    dots.forEach((d, i) => d.addEventListener('click', () => goTo(i)));

    // auto-advance
    let timer = setInterval(() => goTo(current + 1), 5000);
    carousel.addEventListener('mouseenter', () => clearInterval(timer));
    carousel.addEventListener('mouseleave', () => { timer = setInterval(() => goTo(current + 1), 5000); });

    // touch swipe
    let touchX = 0;
    track.addEventListener('touchstart', e => { touchX = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', e => {
      const diff = touchX - e.changedTouches[0].clientX;
      if (Math.abs(diff) > 40) goTo(current + (diff > 0 ? 1 : -1));
    });
  });
})();

/* ── Filter ──────────────────────────────────────────────────── */
(function () {
  document.querySelectorAll('[data-filter-container]').forEach(container => {
    const buttons = container.querySelectorAll('[data-filter]');
    const items = document.querySelectorAll('[data-filter-item]');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const filter = btn.dataset.filter;
        items.forEach(item => {
          const cat = item.dataset.filterItem;
          item.style.display = (filter === 'all' || cat === filter) ? '' : 'none';
        });
      });
    });
  });
})();

/* ── Contact form ────────────────────────────────────────────── */
(function () {
  const form = document.getElementById('contactForm');
  if (!form) return;

  const validate = {
    name: v => v.trim().length >= 2 || 'Name must be at least 2 characters',
    company: v => v.trim().length >= 1 || 'Company name is required',
    email: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) || 'Enter a valid email address',
    phone: v => v.replace(/\D/, '').length >= 10 || 'Enter a valid phone number',
    service: v => v.length > 0 || 'Please select a service',
    message: v => v.trim().length >= 10 || 'Message must be at least 10 characters',
  };

  const showError = (name, msg) => {
    const el = form.querySelector(`[data-error="${name}"]`);
    if (el) { el.textContent = msg; el.style.display = 'block'; }
    form.querySelector(`[name="${name}"]`)?.classList.add('error');
  };
  const clearError = (name) => {
    const el = form.querySelector(`[data-error="${name}"]`);
    if (el) { el.style.display = 'none'; }
    form.querySelector(`[name="${name}"]`)?.classList.remove('error');
  };

  // Live validation
  Object.keys(validate).forEach(name => {
    const el = form.querySelector(`[name="${name}"]`);
    if (!el) return;
    el.addEventListener('blur', () => {
      const result = validate[name](el.value);
      if (result === true) clearError(name); else showError(name, result);
    });
  });

  form.addEventListener('submit', e => {
    e.preventDefault();
    let valid = true;
    const data = {};

    Object.keys(validate).forEach(name => {
      const el = form.querySelector(`[name="${name}"]`);
      const result = validate[name](el?.value ?? '');
      if (result === true) { clearError(name); data[name] = el.value; }
      else { showError(name, result); valid = false; }
    });

    if (!valid) return;

    const email = 'contact@risearka.com';
    const subject = encodeURIComponent(`[RiseArka Enquiry] ${data.service} — ${data.company}`);
    const body = encodeURIComponent(
      `Name: ${data.name}\nCompany: ${data.company}\nEmail: ${data.email}\nPhone: ${data.phone}\nService: ${data.service}\n\nMessage:\n${data.message}`
    );
    window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;

    // Show success
    const successEl = document.getElementById('formSuccess');
    if (successEl) { form.style.display = 'none'; successEl.style.display = 'block'; }
    else showToast('Opening email client…', 'Your default email app will open with the message pre-filled.', 'ok');
  });
})();

/* ── Newsletter form ─────────────────────────────────────────── */
(function () {
  document.querySelectorAll('.newsletter-form').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const input = form.querySelector('input');
      if (!input?.value || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) {
        showToast('Invalid email', 'Please enter a valid email address.', 'err');
        return;
      }
      showToast('Subscribed! 🎉', 'Thanks for subscribing to RiseArka insights.', 'ok');
      input.value = '';
    });
  });
})();

/* ── Toast ───────────────────────────────────────────────────── */
function showToast(title, msg, type = 'ok') {
  let toast = document.getElementById('globalToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'globalToast';
    toast.className = 'toast';
    toast.innerHTML = `
      <div class="toast-icon ${type}">
        ${type === 'ok'
          ? `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`
          : `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`}
      </div>
      <div><div class="toast-msg"></div><div class="toast-sub"></div></div>`;
    document.body.appendChild(toast);
  }
  toast.querySelector('.toast-icon').className = `toast-icon ${type}`;
  toast.querySelector('.toast-msg').textContent = title;
  toast.querySelector('.toast-sub').textContent = msg;
  clearTimeout(toast._timer);
  requestAnimationFrame(() => toast.classList.add('show'));
  toast._timer = setTimeout(() => toast.classList.remove('show'), 4000);
}

/* ── Hero heading word-by-word animation ─────────────────────── */
(function () {
  const h1 = document.querySelector('.hero h1');
  if (!h1) return;

  // Make sure the h1 is visible (override any data-reveal hiding)
  h1.style.opacity = '1';
  h1.style.transform = 'none';
  h1.classList.add('revealed');

  // Walk text nodes only — safe, won't corrupt HTML tags
  const walkTextNodes = (node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent;
      if (!/\S/.test(text)) return; // skip whitespace-only nodes
      const frag = document.createDocumentFragment();
      text.split(/(\s+)/).forEach(part => {
        if (/^\s+$/.test(part)) {
          frag.appendChild(document.createTextNode(part));
        } else if (part.length) {
          const span = document.createElement('span');
          span.className = 'word';
          span.style.cssText = 'display:inline-block;opacity:0;transform:translateY(18px)';
          span.textContent = part;
          frag.appendChild(span);
        }
      });
      node.parentNode.replaceChild(frag, node);
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      Array.from(node.childNodes).forEach(walkTextNodes);
    }
  };

  walkTextNodes(h1);

  const words = h1.querySelectorAll('.word');
  words.forEach((w, i) => {
    w.style.transition = `opacity 0.55s cubic-bezier(0.22,1,0.36,1) ${0.1 + i * 0.1}s, transform 0.55s cubic-bezier(0.22,1,0.36,1) ${0.1 + i * 0.1}s`;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      w.style.opacity = '1';
      w.style.transform = 'none';
    }));
  });
})();

/* ── Stat box animated border on hover ───────────────────────── */
(function () {
  document.querySelectorAll('.stat-box').forEach(box => {
    box.addEventListener('mouseenter', () => box.style.background = 'var(--surface2)');
    box.addEventListener('mouseleave', () => box.style.background = '');
  });
})();

/* ── Card tilt micro-interaction ─────────────────────────────── */
(function () {
  const TILT = 6; // max degrees
  document.querySelectorAll('.service-card, .bento-card, .industry-card, .insight-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width  - 0.5) * TILT;
      const y = ((e.clientY - rect.top)  / rect.height - 0.5) * -TILT;
      card.style.transform = `perspective(600px) rotateX(${y}deg) rotateY(${x}deg) translateY(-4px)`;
    });
    card.addEventListener('mouseleave', () => { card.style.transform = ''; });
  });
})();

/* ── Active nav link ─────────────────────────────────────────── */
(function () {
  const path = window.location.pathname.replace(/\/+$/, '') || '/';
  document.querySelectorAll('.nav-link, .mobile-link, .dropdown-item').forEach(link => {
    const href = link.getAttribute('href');
    if (!href) return;
    const clean = href.replace(/\/+$/, '') || '/';
    if (path === clean || (clean !== '/' && path.startsWith(clean))) {
      link.classList.add('active');
    }
  });
})();

/* ── Theme switcher ──────────────────────────────────────────── */
(function () {
  const THEMES = [
    {
      id: 'midnight',
      label: 'Dark Midnight',
      colors: ['#080C14', '#FF6B00'],
      icon: '🌑'
    },
    {
      id: 'nature',
      label: 'Nature Green',
      colors: ['#EDEFE1', '#275127'],
      icon: '🌿'
    },
    {
      id: 'ocean',
      label: 'Ocean Night',
      colors: ['#060D18', '#00C8E0'],
      icon: '🌊'
    },
    {
      id: 'crimson',
      label: 'Crimson Dusk',
      colors: ['#0F0810', '#E8365D'],
      icon: '🌹'
    },
  ];

  // Apply saved theme
  const saved = localStorage.getItem('risearka-theme') || 'nature';
  applyTheme(saved);

  function applyTheme(id) {
    if (id === 'nature') {
      document.documentElement.removeAttribute('data-theme');
    } else {
      document.documentElement.setAttribute('data-theme', id);
    }
    localStorage.setItem('risearka-theme', id);
    // Update active state in panel if open
    document.querySelectorAll('.theme-option').forEach(opt => {
      opt.classList.toggle('active', opt.dataset.themeId === id);
    });
  }

  // Inject button into .nav-cta once DOM ready
  function injectSwitcher() {
    const navCta = document.querySelector('.nav-cta');
    if (!navCta) return;

    const wrapper = document.createElement('div');
    wrapper.className = 'theme-switcher';

    const btn = document.createElement('button');
    btn.className = 'theme-toggle-btn';
    btn.setAttribute('aria-label', 'Switch theme');
    btn.setAttribute('title', 'Switch theme');
    btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>`;

    const panel = document.createElement('div');
    panel.className = 'theme-panel';
    panel.innerHTML = `<div class="theme-panel-title">Choose Theme</div>`;

    const currentTheme = localStorage.getItem('risearka-theme') || 'midnight';

    THEMES.forEach(t => {
      const opt = document.createElement('button');
      opt.className = 'theme-option' + (t.id === currentTheme ? ' active' : '');
      opt.dataset.themeId = t.id;
      opt.innerHTML = `
        <span class="theme-swatch">
          <span class="theme-swatch-half" style="background:${t.colors[0]}"></span>
          <span class="theme-swatch-half" style="background:${t.colors[1]}"></span>
        </span>
        <span>${t.icon} ${t.label}</span>
        <span class="theme-check">✓</span>`;
      opt.addEventListener('click', () => {
        applyTheme(t.id);
        panel.classList.remove('open');
      });
      panel.appendChild(opt);
    });

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      panel.classList.toggle('open');
    });
    document.addEventListener('click', () => panel.classList.remove('open'));

    wrapper.appendChild(btn);
    wrapper.appendChild(panel);
    navCta.insertBefore(wrapper, navCta.firstChild);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectSwitcher);
  } else {
    injectSwitcher();
  }
})();
